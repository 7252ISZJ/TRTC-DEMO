//
//  SetVideoQualityViewController.h
//  TRTC-API-Example-OC
//
//  Created by bluedang on 2021/4/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SetVideoQualityViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
