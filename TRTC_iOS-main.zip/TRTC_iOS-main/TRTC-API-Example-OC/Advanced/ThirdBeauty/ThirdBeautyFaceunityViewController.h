//
//  ThirdBeautyFaceunityViewController.h
//  TRTC-API-Example-OC
//
//  Created by adams on 2021/4/22.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ThirdBeautyFaceunityViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
