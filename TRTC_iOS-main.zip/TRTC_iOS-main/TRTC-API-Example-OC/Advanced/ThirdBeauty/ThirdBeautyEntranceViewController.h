//
//  ThirdBeautyEntranceViewController.h
//  TRTC-API-Example-OC
//
//  Created by WesleyLei on 2021/8/17.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ThirdBeautyEntranceViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
