//
//  ThirdBeautyTencentEffectViewController.m
//  TRTC-API-Example-OC
//
//  Created by summer on 2022/5/11.
//  Copyright © 2022 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ThirdBeautyTencentEffectViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
