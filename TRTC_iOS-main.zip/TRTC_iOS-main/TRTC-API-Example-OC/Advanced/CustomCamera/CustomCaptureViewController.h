//
//  CustomCaptureViewController.h
//  TRTC-API-Example-OC
//
//  Created by abyyxwang on 2021/4/22.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CustomCaptureViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
