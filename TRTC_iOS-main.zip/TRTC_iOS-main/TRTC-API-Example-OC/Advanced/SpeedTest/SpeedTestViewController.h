//
//  SpeedTestViewController.h
//  TRTC-API-Example-OC
//
//  Created by bluedang on 2021/4/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SpeedTestViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
