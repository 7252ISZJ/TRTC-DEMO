//
//  VideoCallingEnterViewController.h
//  TRTC-API-Example-OC
//
//  Created by bluedang on 2021/4/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

//MARK: 视频通话示例 - 进房入口
@interface VideoCallingEnterViewController : UIViewController
@end

NS_ASSUME_NONNULL_END
