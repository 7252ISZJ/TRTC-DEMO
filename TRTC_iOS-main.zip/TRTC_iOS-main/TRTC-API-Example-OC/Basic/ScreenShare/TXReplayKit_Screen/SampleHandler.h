//
//  SampleHandler.h
//  TXReplayKit_Screen
//
//  Created by dangjiahe on 2021/4/15.
//

#import <ReplayKit/ReplayKit.h>

@interface SampleHandler : RPBroadcastSampleHandler

@end
