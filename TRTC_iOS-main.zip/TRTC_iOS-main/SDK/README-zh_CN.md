# TRTC SDK （iOS）

_[English](README.md) | 简体中文_

Demo编译时会自动下载SDK到此目录。

## 下载地址
- 精简版：[DOWNLOAD](https://liteav.sdk.qcloud.com/download/latest/TXLiteAVSDK_TRTC_iOS_latest.zip)
