# TRTC iOS SDK
[简体中文](README-zh_CN.md) | English

When the demo is compiled, the SDK will be automatically downloaded to this directory.

## Download URL
- Lite: [Download](https://liteav.sdk.qcloud.com/download/latest/TXLiteAVSDK_TRTC_iOS_latest.zip)
